Todo
============

Planned Features
----------------

* Commandline interface
